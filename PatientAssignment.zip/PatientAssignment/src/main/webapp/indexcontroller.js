var index_app = angular.module('myApp', []);
index_app.controller('myCtrl', function($scope, $http) {
	
	 $scope.patient_insert=function()
		{
			
	    	
	    	 
		    $http.get("/PatientAssignment/patientinsert/"+$scope.patient_id+"/"+$scope.patient_name+"/"+$scope.patient_age)
		    .success(function(response)
			{
		    	alert("Patient Account created");
		    	document.getElementById("p_id").value="";
		    	document.getElementById("p_name").value="";
		    	document.getElementById("p_age").value="";
							
			});
	}

	 $scope.patient_update=function()
		{
			
	    	
	    	 
		    $http.get("/PatientAssignment/patientupdate/"+$scope.patient_name+"/"+$scope.patient_age+"/"+$scope.patient_id)
		    .success(function(response)
			{
		    	alert("Patient Account Updated");
		    	document.getElementById("p_id").value="";
		    	document.getElementById("p_name").value="";
		    	document.getElementById("p_age").value="";
							
			});
	}
	    
	 $scope.patient_delete=function()
		{
			
	    	
	    	 
		    $http.get("/PatientAssignment/patientdelete/"+$scope.patient_id)
		    .success(function(response)
			{
		    	alert("Patient Account Deleted");
		    	document.getElementById("p_id").value="";
		    	document.getElementById("p_name").value="";
		    	document.getElementById("p_age").value="";
							
			});
	}
	 
	 
	 $scope.patient_select=function()
		{
			
	    	
	    	 
		    $http.get("/PatientAssignment/patientid/"+$scope.patient_id)
		    .success(function(response)
			{
		    	
		    	
		    	$scope.result=response;
							
			});
	}
	 
});