package com.training.mapper;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.training.model.Patients;

public class PatientMapper implements RowMapper<Patients> {

	public Patients mapRow(ResultSet rs, int rowNum) throws SQLException {
	      Patients obj = new Patients();
	      obj.setId(rs.getInt("id"));
	      obj.setName(rs.getString("name"));
	      obj.setAge(rs.getInt("age"));
	      return obj;
	   }
	
}
